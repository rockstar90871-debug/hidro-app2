## Descripción
(Resume brevemente qué hace este PR)

## Cambios incluidos
- Lista de cambios

## Checklist
- [ ] He ejecutado lint/format
- [ ] Documentación actualizada (README/CHANGELOG si aplica)
- [ ] PR enlaza issue relacionado (si aplica)