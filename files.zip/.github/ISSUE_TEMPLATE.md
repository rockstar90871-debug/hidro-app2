<!-- Gracias por abrir un issue! Por favor completa lo siguiente: -->

- Tipo: bug / enhancement / question
- Descripción breve:
- Pasos para reproducir (si aplica):
- Comportamiento esperado:
- Capturas / consola / información adicional: